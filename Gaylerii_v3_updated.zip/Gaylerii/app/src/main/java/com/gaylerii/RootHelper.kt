package com.gaylerii
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.io.File

object RootHelper {
    fun scanAllMedia(): List<MediaItem> {
        val mediaList = mutableListOf<MediaItem>()
        var process: Process? = null
        var os: DataOutputStream? = null
        var reader: BufferedReader? = null
        try {
            process = Runtime.getRuntime().exec("su")
            os = DataOutputStream(process.outputStream)
            val cmd = "find /storage/emulated/0/ -type f \\( -iname \"*.jpg\" -o -iname \"*.jpeg\" -o -iname \"*.png\" -o -iname \"*.webp\" -o -iname \"*.mp4\" -o -iname \"*.mkv\" \\)\n"
            os.writeBytes(cmd)
            os.writeBytes("exit\n")
            os.flush()
            reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val filePath = line?.trim() ?: continue
                if (filePath.isNotEmpty()) {
                    val file = File(filePath)
                    if (file.exists()) {
                        val isVideo = filePath.endsWith(".mp4", true) || filePath.endsWith(".mkv", true)
                        val dateAdded = file.lastModified()
                        mediaList.add(MediaItem(filePath, isVideo, dateAdded))
                    }
                }
            }
            process.waitFor()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { os?.close() } catch (e: Exception) {}
            try { reader?.close() } catch (e: Exception) {}
            try { process?.destroy() } catch (e: Exception) {}
        }
        return mediaList.sortedByDescending { it.dateAdded }
    }
}
