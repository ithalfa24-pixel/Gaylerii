package com.gaylerii

import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.io.File

object RootHelper {

    private fun execRoot(cmd: String): List<String> {
        val result = mutableListOf<String>()
        var process: Process? = null
        var os: DataOutputStream? = null
        var reader: BufferedReader? = null
        try {
            process = Runtime.getRuntime().exec("su")
            os = DataOutputStream(process.outputStream)
            os.writeBytes("$cmd\n")
            os.writeBytes("exit\n")
            os.flush()
            reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val l = line?.trim() ?: continue
                if (l.isNotEmpty()) result.add(l)
            }
            process.waitFor()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { os?.close() } catch (e: Exception) {}
            try { reader?.close() } catch (e: Exception) {}
            try { process?.destroy() } catch (e: Exception) {}
        }
        return result
    }

    fun scanAllMedia(): List<MediaItem> {
        val cmd = "find /storage/emulated/0/ -type f \\( -iname \"*.jpg\" -o -iname \"*.jpeg\" -o -iname \"*.png\" -o -iname \"*.webp\" -o -iname \"*.mp4\" -o -iname \"*.mkv\" \\)"
        return execRoot(cmd).mapNotNull { filePath ->
            val file = File(filePath)
            if (!file.exists()) return@mapNotNull null
            val name = file.name
            val ext = name.substringAfterLast(".").lowercase()
            val type = if (ext in listOf("mp4", "mov", "avi", "mkv", "webm", "3gp"))
                MediaType.VIDEO else MediaType.IMAGE
            MediaItem(
                path = filePath,
                name = name,
                type = type,
                size = file.length(),
                dateModified = file.lastModified()
            )
        }.sortedByDescending { it.dateModified }
    }

    fun listMediaFiles(directory: String): List<String> {
        val cmd = "find \"$directory\" -maxdepth 1 -type f \\( -iname \"*.jpg\" -o -iname \"*.jpeg\" -o -iname \"*.png\" -o -iname \"*.webp\" -o -iname \"*.mp4\" -o -iname \"*.mkv\" \\)"
        return execRoot(cmd)
    }

    fun getFileSize(path: String): Long {
        return try { File(path).length() } catch (e: Exception) { 0L }
    }

    fun getFileDate(path: String): Long {
        return try { File(path).lastModified() } catch (e: Exception) { 0L }
    }

    fun deleteFile(path: String): Boolean {
        val result = execRoot("rm -f \"$path\"")
        return !File(path).exists()
    }

    fun mediaScan(path: String) {
        execRoot("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d \"file://$path\"")
    }
}
