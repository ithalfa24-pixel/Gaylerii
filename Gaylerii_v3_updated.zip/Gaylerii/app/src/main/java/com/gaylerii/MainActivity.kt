package com.gaylerii
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var mediaAdapter: MediaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val cachedMedia = getCachedMedia()
        if (cachedMedia.isNotEmpty()) {
            mediaAdapter.submitList(cachedMedia)
        }
        loadAndRefreshMedia()
    }

    private fun loadAndRefreshMedia() {
        lifecycleScope.launch(Dispatchers.IO) {
            val freshMedia = RootHelper.scanAllMedia()
            if (freshMedia.isNotEmpty()) {
                saveMediaToCache(freshMedia)
                withContext(Dispatchers.Main) {
                    mediaAdapter.submitList(freshMedia)
                    mediaAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    private fun saveMediaToCache(mediaList: List<MediaItem>) {
        val sharedPreferences = getSharedPreferences("Gaylerii_Cache", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(mediaList)
        editor.putString("cached_media_list", json)
        editor.apply()
    }

    private fun getCachedMedia(): List<MediaItem> {
        val sharedPreferences = getSharedPreferences("Gaylerii_Cache", MODE_PRIVATE)
        val json = sharedPreferences.getString("cached_media_list", null) ?: return emptyList()
        val gson = Gson()
        val type = object : TypeToken<List<MediaItem>>() {}.type
        return gson.fromJson(json, type)
    }
}
