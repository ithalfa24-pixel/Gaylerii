package com.gaylerii

import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.topjohnwu.superuser.Shell

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView
    private lateinit var gallerySection: View
    private lateinit var rvAlbums: RecyclerView
    private lateinit var rvPinned: RecyclerView
    private lateinit var rvAllMedia: RecyclerView
    private lateinit var tvPinnedSection: View
    private lateinit var tvNoPinned: TextView
    private lateinit var tvRootStatus: TextView
    private lateinit var progressBar: ProgressBar

    private lateinit var pinnedAdapter: MediaAdapter
    private lateinit var allMediaAdapter: MediaAdapter
    private lateinit var albumAdapter: AlbumAdapter

    private val allMediaItems = mutableListOf<MediaItem>()
    private val pinnedItems = mutableListOf<MediaItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initViews()
        setupAdapters()
        setupBottomNav()
        checkRootAndLoad()
    }

    private fun initViews() {
        bottomNav     = findViewById(R.id.bottomNav)
        gallerySection= findViewById(R.id.gallerySection)
        rvAlbums      = findViewById(R.id.rvAlbums)
        rvPinned      = findViewById(R.id.rvPinned)
        rvAllMedia    = findViewById(R.id.rvAllMedia)
        tvPinnedSection = findViewById(R.id.pinnedSection)
        tvNoPinned    = findViewById(R.id.tvNoPinned)
        tvRootStatus  = findViewById(R.id.tvRootStatus)
        progressBar   = findViewById(R.id.progressBar)
    }

    private fun setupAdapters() {
        pinnedAdapter = MediaAdapter(pinnedItems,
            onItemClick = { item, _ -> openMedia(item) },
            onItemLongClick = { item, pos -> showMediaOptions(item, pos) }
        )
        rvPinned.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvPinned.adapter = pinnedAdapter

        allMediaAdapter = MediaAdapter(allMediaItems,
            onItemClick = { item, _ -> openMedia(item) },
            onItemLongClick = { item, pos -> showMediaOptions(item, pos) }
        )
        rvAllMedia.layoutManager = GridLayoutManager(this, 3)
        rvAllMedia.adapter = allMediaAdapter

        albumAdapter = AlbumAdapter(emptyList()) { album ->
            startActivity(Intent(this, AlbumDetailActivity::class.java).apply {
                putExtra("album_path", album.path)
                putExtra("album_name", album.name)
            })
        }
        rvAlbums.layoutManager = GridLayoutManager(this, 2)
        rvAlbums.adapter = albumAdapter
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_gallery -> {
                    gallerySection.visibility = View.VISIBLE
                    rvAlbums.visibility = View.GONE
                    true
                }
                R.id.nav_album -> {
                    gallerySection.visibility = View.GONE
                    rvAlbums.visibility = View.VISIBLE
                    loadAlbumsFromMediaStore()
                    true
                }
                else -> false
            }
        }
    }

    private fun checkRootAndLoad() {
        progressBar.visibility = View.VISIBLE
        Shell.getShell { shell ->
            runOnUiThread {
                tvRootStatus.text = "🖼️ Gaylerii"
                loadAllMediaFromMediaStore()
            }
        }
    }

    // ── FAST: pakai MediaStore API ──────────────────────────────────────────

    private fun loadAllMediaFromMediaStore() {
        progressBar.visibility = View.VISIBLE
        Thread {
            val found = mutableListOf<MediaItem>()
            val pinnedPaths = PinManager.getPinnedPaths(this)

            // Query images
            found.addAll(queryMediaStore(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                MediaType.IMAGE, pinnedPaths
            ))
            // Query videos
            found.addAll(queryMediaStore(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                MediaType.VIDEO, pinnedPaths
            ))

            found.sortWith(compareByDescending<MediaItem> { it.isPinned }
                .thenByDescending { it.dateModified })

            val pinned = found.filter { it.isPinned }

            runOnUiThread {
                allMediaItems.clear()
                allMediaItems.addAll(found)
                allMediaAdapter.notifyDataSetChanged()

                pinnedItems.clear()
                pinnedItems.addAll(pinned)
                pinnedAdapter.notifyDataSetChanged()

                updatePinnedVisibility()
                progressBar.visibility = View.GONE
            }
        }.start()
    }

    private fun queryMediaStore(
        uri: Uri,
        type: MediaType,
        pinnedPaths: Set<String>
    ): List<MediaItem> {
        val result = mutableListOf<MediaItem>()
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED
        )
        val cursor: Cursor? = contentResolver.query(
            uri, projection, null, null,
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )
        cursor?.use {
            val idCol   = it.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val dataCol = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
            val sizeCol = it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val dateCol = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            while (it.moveToNext()) {
                val path = it.getString(dataCol) ?: continue
                result.add(MediaItem(
                    path         = path,
                    name         = it.getString(nameCol) ?: path.substringAfterLast("/"),
                    type         = type,
                    size         = it.getLong(sizeCol),
                    dateModified = it.getLong(dateCol) * 1000L,
                    isPinned     = pinnedPaths.contains(path)
                ))
            }
        }
        return result
    }

    private fun loadAlbumsFromMediaStore() {
        Thread {
            val albumMap = mutableMapOf<String, Album>()

            listOf(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            ).forEach { uri ->
                val projection = arrayOf(
                    MediaStore.MediaColumns.DATA,
                    MediaStore.MediaColumns.DISPLAY_NAME
                )
                val cursor = contentResolver.query(uri, projection, null, null, null)
                cursor?.use {
                    val dataCol = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                    while (it.moveToNext()) {
                        val path   = it.getString(dataCol) ?: return@use
                        val folder = path.substringBeforeLast("/")
                        val name   = folder.substringAfterLast("/")
                        val existing = albumMap[folder]
                        if (existing == null) {
                            albumMap[folder] = Album(
                                name       = name,
                                path       = folder,
                                coverPath  = path,
                                mediaCount = 1
                            )
                        } else {
                            albumMap[folder] = existing.copy(mediaCount = existing.mediaCount + 1)
                        }
                    }
                }
            }

            val albums = albumMap.values.sortedByDescending { it.mediaCount }
            runOnUiThread { albumAdapter.updateAlbums(albums) }
        }.start()
    }

    // ── Actions ─────────────────────────────────────────────────────────────

    private fun showMediaOptions(item: MediaItem, position: Int) {
        val pinLabel = if (item.isPinned) "Lepas Pin" else "📌 Pin"
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(arrayOf(pinLabel, "🗑️ Hapus", "Batal")) { _, which ->
                when (which) {
                    0 -> togglePin(item, position)
                    1 -> confirmDelete(item)
                }
            }.show()
    }

    private fun togglePin(item: MediaItem, position: Int) {
        val nowPinned = PinManager.togglePin(this, item.path)
        item.isPinned = nowPinned
        if (nowPinned) {
            pinnedItems.add(0, item)
            pinnedAdapter.notifyItemInserted(0)
            Toast.makeText(this, "📌 Disematkan", Toast.LENGTH_SHORT).show()
        } else {
            val idx = pinnedItems.indexOfFirst { it.path == item.path }
            if (idx >= 0) { pinnedItems.removeAt(idx); pinnedAdapter.notifyItemRemoved(idx) }
            Toast.makeText(this, "Pin dilepas", Toast.LENGTH_SHORT).show()
        }
        val allIdx = allMediaItems.indexOfFirst { it.path == item.path }
        if (allIdx >= 0) { allMediaItems[allIdx] = item; allMediaAdapter.notifyItemChanged(allIdx) }
        updatePinnedVisibility()
    }

    private fun confirmDelete(item: MediaItem) {
        AlertDialog.Builder(this)
            .setTitle("Hapus")
            .setMessage("Hapus \"${item.name}\"?")
            .setPositiveButton("Hapus") { _, _ ->
                Thread {
                    val success = RootHelper.deleteFile(item.path)
                    RootHelper.mediaScan(item.path)
                    runOnUiThread {
                        if (success) {
                            val allIdx = allMediaItems.indexOfFirst { it.path == item.path }
                            if (allIdx >= 0) { allMediaItems.removeAt(allIdx); allMediaAdapter.notifyItemRemoved(allIdx) }
                            val pinIdx = pinnedItems.indexOfFirst { it.path == item.path }
                            if (pinIdx >= 0) { pinnedItems.removeAt(pinIdx); pinnedAdapter.notifyItemRemoved(pinIdx) }
                            PinManager.unpin(this, item.path)
                            updatePinnedVisibility()
                            Toast.makeText(this, "🗑️ Dihapus", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Gagal menghapus", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.start()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun openMedia(item: MediaItem) {
        startActivity(Intent(this, MediaViewerActivity::class.java).apply {
            putExtra("media_path", item.path)
            putExtra("media_type", item.type.name)
        })
    }

    private fun updatePinnedVisibility() {
        val has = pinnedItems.isNotEmpty()
        tvPinnedSection.visibility = if (has) View.VISIBLE else View.GONE
        rvPinned.visibility        = if (has) View.VISIBLE else View.GONE
        tvNoPinned.visibility      = if (!has) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        val pinnedPaths = PinManager.getPinnedPaths(this)
        allMediaItems.forEach { it.isPinned = pinnedPaths.contains(it.path) }
        allMediaAdapter.notifyDataSetChanged()
        pinnedItems.clear()
        pinnedItems.addAll(allMediaItems.filter { it.isPinned })
        pinnedAdapter.notifyDataSetChanged()
        updatePinnedVisibility()
    }
}
