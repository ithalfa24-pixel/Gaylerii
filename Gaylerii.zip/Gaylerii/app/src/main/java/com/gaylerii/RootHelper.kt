package com.gaylerii

import com.topjohnwu.superuser.Shell

object RootHelper {

    fun exec(command: String): String {
        val result = Shell.cmd(command).exec()
        return if (result.isSuccess) {
            result.out.joinToString("\n")
        } else {
            "ERROR: ${result.err.joinToString("\n")}"
        }
    }

    fun isDirectory(path: String): Boolean {
        val result = Shell.cmd("[ -d \"$path\" ] && echo yes || echo no").exec()
        return result.out.firstOrNull()?.trim() == "yes"
    }

    fun deleteFile(path: String): Boolean {
        val result = Shell.cmd("rm -f \"$path\"").exec()
        return result.isSuccess
    }

    fun mediaScan(path: String) {
        Shell.cmd("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d \"file://$path\"").exec()
    }

    /**
     * Daftar semua file gambar & video di suatu folder
     */
    fun listMediaFiles(directory: String): List<String> {
        val cmd = "find \"$directory\" -maxdepth 1 -type f \\( " +
                "-iname \"*.jpg\" -o -iname \"*.jpeg\" -o -iname \"*.png\" " +
                "-o -iname \"*.gif\" -o -iname \"*.webp\" " +
                "-o -iname \"*.mp4\" -o -iname \"*.mov\" -o -iname \"*.avi\" " +
                "-o -iname \"*.mkv\" -o -iname \"*.webm\" -o -iname \"*.3gp\" \\)"
        val result = Shell.cmd(cmd).exec()
        return if (result.isSuccess) result.out.filter { it.isNotBlank() } else emptyList()
    }

    /**
     * Daftar semua sub-folder (album) di path tertentu
     */
    fun listDirectories(path: String): List<String> {
        val result = Shell.cmd("find \"$path\" -maxdepth 1 -mindepth 1 -type d").exec()
        return if (result.isSuccess) result.out.filter { it.isNotBlank() } else emptyList()
    }

    /**
     * Ambil ukuran file dalam bytes
     */
    fun getFileSize(path: String): Long {
        val result = Shell.cmd("stat -c %s \"$path\"").exec()
        return result.out.firstOrNull()?.trim()?.toLongOrNull() ?: 0L
    }

    /**
     * Ambil tanggal modifikasi file (unix timestamp)
     */
    fun getFileDate(path: String): Long {
        val result = Shell.cmd("stat -c %Y \"$path\"").exec()
        return (result.out.firstOrNull()?.trim()?.toLongOrNull() ?: 0L) * 1000L
    }

    /**
     * Daftar semua file media secara rekursif
     */
    fun listMediaFilesRecursive(directory: String): List<String> {
        val cmd = "find \"$directory\" -type f \\( " +
                "-iname \"*.jpg\" -o -iname \"*.jpeg\" -o -iname \"*.png\" " +
                "-o -iname \"*.gif\" -o -iname \"*.webp\" " +
                "-o -iname \"*.mp4\" -o -iname \"*.mov\" -o -iname \"*.avi\" " +
                "-o -iname \"*.mkv\" -o -iname \"*.webm\" -o -iname \"*.3gp\" \\)"
        val result = Shell.cmd(cmd).exec()
        return if (result.isSuccess) result.out.filter { it.isNotBlank() } else emptyList()
    }

    /**
     * Hitung jumlah file media di folder
     */
    fun countMediaInFolder(directory: String): Int {
        val cmd = "find \"$directory\" -maxdepth 1 -type f \\( " +
                "-iname \"*.jpg\" -o -iname \"*.jpeg\" -o -iname \"*.png\" " +
                "-o -iname \"*.gif\" -o -iname \"*.webp\" " +
                "-o -iname \"*.mp4\" -o -iname \"*.mov\" -o -iname \"*.avi\" " +
                "-o -iname \"*.mkv\" -o -iname \"*.webm\" -o -iname \"*.3gp\" \\) | wc -l"
        val result = Shell.cmd(cmd).exec()
        return result.out.firstOrNull()?.trim()?.toIntOrNull() ?: 0
    }
}
