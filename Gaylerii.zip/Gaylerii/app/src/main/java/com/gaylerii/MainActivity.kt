package com.gaylerii

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.topjohnwu.superuser.Shell

class MainActivity : AppCompatActivity() {

    // Views
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var gallerySection: View
    private lateinit var albumSection: View

    // Gallery views
    private lateinit var rvPinned: RecyclerView
    private lateinit var rvAllMedia: RecyclerView
    private lateinit var tvPinnedSection: View
    private lateinit var tvNoPinned: TextView
    private lateinit var tvRootStatus: TextView
    private lateinit var progressBar: ProgressBar

    // Album views
    private lateinit var rvAlbums: RecyclerView

    // Adapters
    private lateinit var pinnedAdapter: MediaAdapter
    private lateinit var allMediaAdapter: MediaAdapter
    private lateinit var albumAdapter: AlbumAdapter

    // Data
    private val allMediaItems = mutableListOf<MediaItem>()
    private val pinnedItems = mutableListOf<MediaItem>()

    // Base paths to scan
    private val SCAN_PATHS = listOf(
        "/sdcard/DCIM",
        "/sdcard/Pictures",
        "/sdcard/Movies",
        "/sdcard/Videos",
        "/sdcard/Download"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupAdapters()
        setupBottomNav()
        checkRootAndLoad()
    }

    private fun initViews() {
        bottomNav = findViewById(R.id.bottomNav)
        gallerySection = findViewById(R.id.gallerySection)
        albumSection = findViewById(R.id.albumSection)
        rvPinned = findViewById(R.id.rvPinned)
        rvAllMedia = findViewById(R.id.rvAllMedia)
        tvPinnedSection = findViewById(R.id.pinnedSection)
        tvNoPinned = findViewById(R.id.tvNoPinned)
        tvRootStatus = findViewById(R.id.tvRootStatus)
        progressBar = findViewById(R.id.progressBar)
        rvAlbums = findViewById(R.id.rvAlbums)
    }

    private fun setupAdapters() {
        // Pinned adapter (horizontal)
        pinnedAdapter = MediaAdapter(
            pinnedItems,
            onItemClick = { item, _ -> openMedia(item) },
            onItemLongClick = { item, pos -> showMediaOptions(item, pos, true) }
        )
        rvPinned.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvPinned.adapter = pinnedAdapter

        // All media adapter (3-column grid)
        allMediaAdapter = MediaAdapter(
            allMediaItems,
            onItemClick = { item, _ -> openMedia(item) },
            onItemLongClick = { item, pos -> showMediaOptions(item, pos, false) }
        )
        rvAllMedia.layoutManager = GridLayoutManager(this, 3)
        rvAllMedia.adapter = allMediaAdapter

        // Album adapter (2-column grid)
        albumAdapter = AlbumAdapter(emptyList()) { album ->
            val intent = Intent(this, AlbumDetailActivity::class.java)
            intent.putExtra("album_path", album.path)
            intent.putExtra("album_name", album.name)
            startActivity(intent)
        }
        rvAlbums.layoutManager = GridLayoutManager(this, 2)
        rvAlbums.adapter = albumAdapter
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_gallery -> {
                    gallerySection.visibility = View.VISIBLE
                    albumSection.visibility = View.GONE
                    true
                }
                R.id.nav_album -> {
                    gallerySection.visibility = View.GONE
                    albumSection.visibility = View.VISIBLE
                    loadAlbums()
                    true
                }
                else -> false
            }
        }
    }

    private fun checkRootAndLoad() {
        progressBar.visibility = View.VISIBLE
        Shell.getShell { shell ->
            runOnUiThread {
                if (shell.isRoot) {
                    tvRootStatus.text = "🖼️ Gaylerii"
                    loadAllMedia()
                } else {
                    tvRootStatus.text = "❌ Root diperlukan"
                    progressBar.visibility = View.GONE
                    Toast.makeText(this, "Akses root tidak tersedia!", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun loadAllMedia() {
        progressBar.visibility = View.VISIBLE
        Thread {
            val found = mutableListOf<MediaItem>()
            val pinnedPaths = PinManager.getPinnedPaths(this)

            for (basePath in SCAN_PATHS) {
                if (!RootHelper.isDirectory(basePath)) continue
                val files = RootHelper.listMediaFilesRecursive(basePath)
                for (path in files) {
                    val name = path.substringAfterLast("/")
                    val ext = name.substringAfterLast(".").lowercase()
                    val type = if (ext in listOf("mp4", "mov", "avi", "mkv", "webm", "3gp"))
                        MediaType.VIDEO else MediaType.IMAGE
                    found.add(
                        MediaItem(
                            path = path,
                            name = name,
                            type = type,
                            size = RootHelper.getFileSize(path),
                            dateModified = RootHelper.getFileDate(path),
                            isPinned = pinnedPaths.contains(path)
                        )
                    )
                }
            }

            // Sort: pinned first, then by date
            found.sortWith(compareByDescending<MediaItem> { it.isPinned }.thenByDescending { it.dateModified })

            val pinned = found.filter { it.isPinned }

            runOnUiThread {
                allMediaItems.clear()
                allMediaItems.addAll(found)
                allMediaAdapter.notifyDataSetChanged()

                pinnedItems.clear()
                pinnedItems.addAll(pinned)
                pinnedAdapter.notifyDataSetChanged()

                updatePinnedVisibility()
                progressBar.visibility = View.GONE
            }
        }.start()
    }

    private fun loadAlbums() {
        Thread {
            val albums = mutableListOf<Album>()
            for (basePath in SCAN_PATHS) {
                if (!RootHelper.isDirectory(basePath)) continue
                val dirs = RootHelper.listDirectories(basePath)
                for (dir in dirs) {
                    val count = RootHelper.countMediaInFolder(dir)
                    if (count > 0) {
                        val files = RootHelper.listMediaFiles(dir)
                        val cover = files.firstOrNull()
                        albums.add(
                            Album(
                                name = dir.substringAfterLast("/"),
                                path = dir,
                                coverPath = cover,
                                mediaCount = count
                            )
                        )
                    }
                }
            }
            runOnUiThread {
                albumAdapter.updateAlbums(albums)
            }
        }.start()
    }

    private fun showMediaOptions(item: MediaItem, position: Int, isPinnedList: Boolean) {
        val pinLabel = if (item.isPinned) "Lepas Pin" else "📌 Pin"
        val options = arrayOf(pinLabel, "🗑️ Hapus", "Batal")

        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> togglePin(item, position, isPinnedList)
                    1 -> confirmDelete(item, position, isPinnedList)
                }
            }
            .show()
    }

    private fun togglePin(item: MediaItem, position: Int, isPinnedList: Boolean) {
        val nowPinned = PinManager.togglePin(this, item.path)
        item.isPinned = nowPinned

        if (nowPinned) {
            pinnedItems.add(0, item)
            pinnedAdapter.notifyItemInserted(0)
            Toast.makeText(this, "📌 Disematkan", Toast.LENGTH_SHORT).show()
        } else {
            val pinIdx = pinnedItems.indexOfFirst { it.path == item.path }
            if (pinIdx >= 0) {
                pinnedItems.removeAt(pinIdx)
                pinnedAdapter.notifyItemRemoved(pinIdx)
            }
            Toast.makeText(this, "Pin dilepas", Toast.LENGTH_SHORT).show()
        }

        // Update in all media list
        val allIdx = allMediaItems.indexOfFirst { it.path == item.path }
        if (allIdx >= 0) {
            allMediaItems[allIdx] = item
            allMediaAdapter.notifyItemChanged(allIdx)
        }

        updatePinnedVisibility()
    }

    private fun confirmDelete(item: MediaItem, position: Int, isPinnedList: Boolean) {
        AlertDialog.Builder(this)
            .setTitle("Hapus")
            .setMessage("Hapus \"${item.name}\"?")
            .setPositiveButton("Hapus") { _, _ -> deleteMedia(item) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteMedia(item: MediaItem) {
        Thread {
            val success = RootHelper.deleteFile(item.path)
            RootHelper.mediaScan(item.path)

            runOnUiThread {
                if (success) {
                    // Remove from all lists
                    val allIdx = allMediaItems.indexOfFirst { it.path == item.path }
                    if (allIdx >= 0) {
                        allMediaItems.removeAt(allIdx)
                        allMediaAdapter.notifyItemRemoved(allIdx)
                    }
                    val pinIdx = pinnedItems.indexOfFirst { it.path == item.path }
                    if (pinIdx >= 0) {
                        pinnedItems.removeAt(pinIdx)
                        pinnedAdapter.notifyItemRemoved(pinIdx)
                    }
                    PinManager.unpin(this, item.path)
                    updatePinnedVisibility()
                    Toast.makeText(this, "🗑️ File dihapus", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Gagal menghapus file", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun openMedia(item: MediaItem) {
        val intent = Intent(this, MediaViewerActivity::class.java)
        intent.putExtra("media_path", item.path)
        intent.putExtra("media_type", item.type.name)
        startActivity(intent)
    }

    private fun updatePinnedVisibility() {
        val hasPinned = pinnedItems.isNotEmpty()
        tvPinnedSection.visibility = if (hasPinned) View.VISIBLE else View.GONE
        rvPinned.visibility = if (hasPinned) View.VISIBLE else View.GONE
        tvNoPinned.visibility = if (!hasPinned) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        // Refresh pin states
        val pinnedPaths = PinManager.getPinnedPaths(this)
        allMediaItems.forEach { it.isPinned = pinnedPaths.contains(it.path) }
        allMediaAdapter.notifyDataSetChanged()
        pinnedItems.clear()
        pinnedItems.addAll(allMediaItems.filter { it.isPinned })
        pinnedAdapter.notifyDataSetChanged()
        updatePinnedVisibility()
    }
}
