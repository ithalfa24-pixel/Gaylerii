# 🖼️ Gaylerii

Aplikasi galeri foto & video Android dengan akses root.

---

## ✨ Fitur

- 📌 **Pin foto/video** — sematkan media favorit, tampil di bagian atas
- 🗑️ **Hapus foto/video** — hapus langsung via root
- 📁 **Album** — jelajahi folder media secara terstruktur
- 🎬 **Putar video** — built-in video player
- 🖼️ **Lihat foto** — full screen image viewer
- 🔄 **Auto scan** — scan semua folder media otomatis

---

## 📂 Folder yang Dipindai

| Folder |
|--------|
| `/sdcard/DCIM` |
| `/sdcard/Pictures` |
| `/sdcard/Movies` |
| `/sdcard/Videos` |
| `/sdcard/Download` |

---

## ⚙️ Cara Setup di Android Studio

1. Buka Android Studio → **Open Project** → pilih folder `Gaylerii`
2. Tunggu Gradle sync selesai
3. Colok HP ke PC via USB, aktifkan **USB Debugging**
4. Klik **Run** ▶

---

## ⚠️ Persyaratan

- HP sudah **root** (Magisk / SuperSU)
- Android 8.0+ (API 26+)

---

## 🔧 Kustomisasi Folder Scan

Edit list `SCAN_PATHS` di `MainActivity.kt`:

```kotlin
private val SCAN_PATHS = listOf(
    "/sdcard/DCIM",
    "/sdcard/Pictures",
    "/sdcard/Movies",
    "/sdcard/Videos",
    "/sdcard/Download"
)
```

---

## 🏗️ Struktur Project

```
Gaylerii/
├── app/src/main/
│   ├── java/com/gaylerii/
│   │   ├── MainActivity.kt          ← UI utama (Galeri + Album)
│   │   ├── AlbumDetailActivity.kt   ← Isi album
│   │   ├── MediaViewerActivity.kt   ← Lihat foto/video fullscreen
│   │   ├── MediaAdapter.kt          ← Adapter grid media
│   │   ├── AlbumAdapter.kt          ← Adapter grid album
│   │   ├── RootHelper.kt            ← Operasi file via root
│   │   ├── PinManager.kt            ← Manajemen pin (SharedPrefs)
│   │   └── MediaItem.kt             ← Data model
│   └── res/
│       ├── layout/                  ← XML layouts
│       ├── drawable/                ← Icons & backgrounds
│       ├── values/                  ← Colors, themes, strings
│       └── menu/                    ← Bottom navigation menu
└── README.md
```
