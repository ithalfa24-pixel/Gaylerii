package com.gaylerii

data class MediaItem(
    val path: String,
    val name: String,
    val type: MediaType,
    val size: Long = 0L,
    val dateModified: Long = 0L,
    var isPinned: Boolean = false
)

enum class MediaType {
    IMAGE, VIDEO
}

data class Album(
    val name: String,
    val path: String,
    val coverPath: String?,
    val mediaCount: Int
)
