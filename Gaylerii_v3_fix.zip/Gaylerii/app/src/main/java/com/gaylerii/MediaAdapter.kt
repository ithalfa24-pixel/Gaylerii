package com.gaylerii

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.io.File

class MediaAdapter(
    private var items: MutableList<MediaItem>,
    private val onItemClick: (MediaItem, Int) -> Unit,
    private val onItemLongClick: (MediaItem, Int) -> Unit
) : RecyclerView.Adapter<MediaAdapter.MediaViewHolder>() {

    inner class MediaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val thumbnail: ImageView = view.findViewById(R.id.imgThumbnail)
        val ivVideoIcon: ImageView = view.findViewById(R.id.ivVideoIcon)
        val ivPin: ImageView = view.findViewById(R.id.ivPin)
        val tvDuration: TextView = view.findViewById(R.id.tvDuration)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MediaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_media, parent, false)
        return MediaViewHolder(view)
    }

    override fun onBindViewHolder(holder: MediaViewHolder, position: Int) {
        val item = items[position]

        Glide.with(holder.itemView.context)
            .load(File(item.path))
            .centerCrop()
            .placeholder(R.drawable.bg_media_placeholder)
            .into(holder.thumbnail)

        holder.ivVideoIcon.visibility = if (item.type == MediaType.VIDEO) View.VISIBLE else View.GONE
        holder.tvDuration.visibility = if (item.type == MediaType.VIDEO) View.VISIBLE else View.GONE
        holder.ivPin.visibility = if (item.isPinned) View.VISIBLE else View.GONE

        holder.itemView.setOnClickListener { onItemClick(item, position) }
        holder.itemView.setOnLongClickListener {
            onItemLongClick(item, position)
            true
        }
    }

    override fun getItemCount() = items.size

    fun updateItems(newItems: List<MediaItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun removeItem(position: Int) {
        items.removeAt(position)
        notifyItemRemoved(position)
    }

    fun updateItem(position: Int, item: MediaItem) {
        items[position] = item
        notifyItemChanged(position)
    }
}
