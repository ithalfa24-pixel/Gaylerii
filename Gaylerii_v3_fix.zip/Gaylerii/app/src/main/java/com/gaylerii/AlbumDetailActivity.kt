package com.gaylerii

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AlbumDetailActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var rvMedia: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var adapter: MediaAdapter

    private val mediaItems = mutableListOf<MediaItem>()
    private var albumPath: String = ""
    private var albumName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_album_detail)

        albumPath = intent.getStringExtra("album_path") ?: ""
        albumName = intent.getStringExtra("album_name") ?: "Album"

        toolbar = findViewById(R.id.toolbar)
        rvMedia = findViewById(R.id.rvMedia)
        progressBar = findViewById(R.id.progressBar)

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = albumName

        adapter = MediaAdapter(
            mediaItems,
            onItemClick = { item, _ ->
                val intent = Intent(this, MediaViewerActivity::class.java)
                intent.putExtra("media_path", item.path)
                intent.putExtra("media_type", item.type.name)
                startActivity(intent)
            },
            onItemLongClick = { item, pos -> showOptions(item, pos) }
        )
        rvMedia.layoutManager = GridLayoutManager(this, 3)
        rvMedia.adapter = adapter

        loadMedia()
    }

    private fun loadMedia() {
        progressBar.visibility = View.VISIBLE
        Thread {
            val pinnedPaths = PinManager.getPinnedPaths(this)
            val files = RootHelper.listMediaFiles(albumPath)
            val items = files.map { path ->
                val name = path.substringAfterLast("/")
                val ext = name.substringAfterLast(".").lowercase()
                val type = if (ext in listOf("mp4", "mov", "avi", "mkv", "webm", "3gp"))
                    MediaType.VIDEO else MediaType.IMAGE
                MediaItem(
                    path = path,
                    name = name,
                    type = type,
                    size = RootHelper.getFileSize(path),
                    dateModified = RootHelper.getFileDate(path),
                    isPinned = pinnedPaths.contains(path)
                )
            }.sortedByDescending { it.dateModified }

            runOnUiThread {
                mediaItems.clear()
                mediaItems.addAll(items)
                adapter.notifyDataSetChanged()
                progressBar.visibility = View.GONE
            }
        }.start()
    }

    private fun showOptions(item: MediaItem, position: Int) {
        val pinLabel = if (item.isPinned) "Lepas Pin" else "📌 Pin"
        val options = arrayOf(pinLabel, "🗑️ Hapus", "Batal")
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val nowPinned = PinManager.togglePin(this, item.path)
                        item.isPinned = nowPinned
                        adapter.updateItem(position, item)
                        Toast.makeText(this, if (nowPinned) "📌 Disematkan" else "Pin dilepas", Toast.LENGTH_SHORT).show()
                    }
                    1 -> {
                        AlertDialog.Builder(this)
                            .setTitle("Hapus")
                            .setMessage("Hapus \"${item.name}\"?")
                            .setPositiveButton("Hapus") { _, _ ->
                                Thread {
                                    val success = RootHelper.deleteFile(item.path)
                                    RootHelper.mediaScan(item.path)
                                    runOnUiThread {
                                        if (success) {
                                            adapter.removeItem(position)
                                            PinManager.unpin(this, item.path)
                                            Toast.makeText(this, "🗑️ Dihapus", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(this, "Gagal menghapus", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }.start()
                            }
                            .setNegativeButton("Batal", null)
                            .show()
                    }
                }
            }.show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
