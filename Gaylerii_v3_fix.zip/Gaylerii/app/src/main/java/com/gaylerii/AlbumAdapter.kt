package com.gaylerii

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.io.File

class AlbumAdapter(
    private var albums: List<Album>,
    private val onAlbumClick: (Album) -> Unit
) : RecyclerView.Adapter<AlbumAdapter.AlbumViewHolder>() {

    inner class AlbumViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgCover: ImageView = view.findViewById(R.id.imgAlbumCover)
        val tvName: TextView = view.findViewById(R.id.tvAlbumName)
        val tvCount: TextView = view.findViewById(R.id.tvAlbumCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_album, parent, false)
        return AlbumViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlbumViewHolder, position: Int) {
        val album = albums[position]

        if (album.coverPath != null) {
            Glide.with(holder.itemView.context)
                .load(File(album.coverPath))
                .centerCrop()
                .placeholder(R.drawable.bg_media_placeholder)
                .into(holder.imgCover)
        } else {
            holder.imgCover.setImageResource(R.drawable.bg_media_placeholder)
        }

        holder.tvName.text = album.name
        holder.tvCount.text = "${album.mediaCount} item"

        holder.itemView.setOnClickListener { onAlbumClick(album) }
    }

    override fun getItemCount() = albums.size

    fun updateAlbums(newAlbums: List<Album>) {
        albums = newAlbums
        notifyDataSetChanged()
    }
}
