package com.gaylerii

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView
    private lateinit var gallerySection: View
    private lateinit var rvAlbums: RecyclerView
    private lateinit var rvPinned: RecyclerView
    private lateinit var rvAllMedia: RecyclerView
    private lateinit var tvPinnedSection: View
    private lateinit var tvNoPinned: TextView
    private lateinit var tvRootStatus: TextView
    private lateinit var progressBar: ProgressBar

    private lateinit var pinnedAdapter: MediaAdapter
    private lateinit var allMediaAdapter: MediaAdapter
    private lateinit var albumAdapter: AlbumAdapter

    private val allMediaItems = mutableListOf<MediaItem>()
    private val pinnedItems = mutableListOf<MediaItem>()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { loadAllMedia() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initViews()
        setupAdapters()
        setupBottomNav()
        checkPermissionsAndLoad()
    }

    private fun initViews() {
        bottomNav       = findViewById(R.id.bottomNav)
        gallerySection  = findViewById(R.id.gallerySection)
        rvAlbums        = findViewById(R.id.rvAlbums)
        rvPinned        = findViewById(R.id.rvPinned)
        rvAllMedia      = findViewById(R.id.rvAllMedia)
        tvPinnedSection = findViewById(R.id.pinnedSection)
        tvNoPinned      = findViewById(R.id.tvNoPinned)
        tvRootStatus    = findViewById(R.id.tvRootStatus)
        progressBar     = findViewById(R.id.progressBar)
    }

    private fun setupAdapters() {
        pinnedAdapter = MediaAdapter(pinnedItems,
            onItemClick = { item, _ -> openMedia(item) },
            onItemLongClick = { item, pos -> showMediaOptions(item, pos) }
        )
        rvPinned.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvPinned.adapter = pinnedAdapter

        allMediaAdapter = MediaAdapter(allMediaItems,
            onItemClick = { item, _ -> openMedia(item) },
            onItemLongClick = { item, pos -> showMediaOptions(item, pos) }
        )
        rvAllMedia.layoutManager = GridLayoutManager(this, 3)
        rvAllMedia.adapter = allMediaAdapter

        albumAdapter = AlbumAdapter(emptyList()) { album ->
            startActivity(Intent(this, AlbumDetailActivity::class.java).apply {
                putExtra("album_path", album.path)
                putExtra("album_name", album.name)
            })
        }
        rvAlbums.layoutManager = GridLayoutManager(this, 2)
        rvAlbums.adapter = albumAdapter
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_gallery -> {
                    gallerySection.visibility = View.VISIBLE
                    rvAlbums.visibility = View.GONE
                    true
                }
                R.id.nav_album -> {
                    gallerySection.visibility = View.GONE
                    rvAlbums.visibility = View.VISIBLE
                    loadAlbums()
                    true
                }
                else -> false
            }
        }
    }

    private fun checkPermissionsAndLoad() {
        tvRootStatus.text = "🖼️ Gaylerii"

        // Tampilkan cache dulu biar loading instan
        val cached = getCachedMedia()
        if (cached.isNotEmpty()) {
            val pinnedPaths = PinManager.getPinnedPaths(this)
            allMediaItems.clear()
            allMediaItems.addAll(cached.map { it.copy(isPinned = pinnedPaths.contains(it.path)) })
            allMediaAdapter.notifyDataSetChanged()
            pinnedItems.clear()
            pinnedItems.addAll(allMediaItems.filter { it.isPinned })
            pinnedAdapter.notifyDataSetChanged()
            updatePinnedVisibility()
        }

        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val allGranted = perms.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) loadAllMedia() else permissionLauncher.launch(perms)
    }

    private fun loadAllMedia() {
        progressBar.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            val pinnedPaths = PinManager.getPinnedPaths(this@MainActivity)
            val cmd = """find /storage/emulated/0/ \
                -type f \( \
                -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.gif" -o -iname "*.webp" \
                -o -iname "*.mp4" -o -iname "*.mov" -o -iname "*.avi" -o -iname "*.mkv" -o -iname "*.3gp" \
                \) 2>/dev/null"""

            val result = Shell.cmd(cmd).exec()
            val found = mutableListOf<MediaItem>()

            for (path in result.out.filter { it.isNotBlank() }) {
                val name = path.substringAfterLast("/")
                val ext  = name.substringAfterLast(".").lowercase()
                val type = if (ext in listOf("mp4","mov","avi","mkv","webm","3gp"))
                    MediaType.VIDEO else MediaType.IMAGE
                found.add(MediaItem(
                    path     = path,
                    name     = name,
                    type     = type,
                    isPinned = pinnedPaths.contains(path)
                ))
            }

            found.sortWith(compareByDescending<MediaItem> { it.isPinned }.thenByDescending { RootHelper.getFileDate(it.path) })
            val pinned = found.filter { it.isPinned }

            // Simpan ke cache
            saveMediaToCache(found)

            withContext(Dispatchers.Main) {
                allMediaItems.clear()
                allMediaItems.addAll(found)
                allMediaAdapter.notifyDataSetChanged()
                pinnedItems.clear()
                pinnedItems.addAll(pinned)
                pinnedAdapter.notifyDataSetChanged()
                updatePinnedVisibility()
                progressBar.visibility = View.GONE
            }
        }
    }

    private fun loadAlbums() {
        lifecycleScope.launch(Dispatchers.IO) {
            val cmd = """find /storage/emulated/0/ \
                -maxdepth 2 -type f \( \
                -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.gif" -o -iname "*.webp" \
                -o -iname "*.mp4" -o -iname "*.mov" -o -iname "*.avi" -o -iname "*.mkv" -o -iname "*.3gp" \
                \) 2>/dev/null"""

            val result = Shell.cmd(cmd).exec()
            val albumMap = mutableMapOf<String, Album>()

            for (path in result.out.filter { it.isNotBlank() }) {
                val folder = path.substringBeforeLast("/")
                val name   = folder.substringAfterLast("/")
                val existing = albumMap[folder]
                if (existing == null) {
                    albumMap[folder] = Album(name = name, path = folder, coverPath = path, mediaCount = 1)
                } else {
                    albumMap[folder] = existing.copy(mediaCount = existing.mediaCount + 1)
                }
            }

            val albums = albumMap.values.sortedByDescending { it.mediaCount }
            withContext(Dispatchers.Main) { albumAdapter.updateAlbums(albums) }
        }
    }

    // ── Cache ────────────────────────────────────────────────────────────────

    private fun saveMediaToCache(mediaList: List<MediaItem>) {
        val prefs = getSharedPreferences("Gaylerii_Cache", MODE_PRIVATE)
        prefs.edit().putString("cached_media_list", Gson().toJson(mediaList)).apply()
    }

    private fun getCachedMedia(): List<MediaItem> {
        val json = getSharedPreferences("Gaylerii_Cache", MODE_PRIVATE)
            .getString("cached_media_list", null) ?: return emptyList()
        return try {
            Gson().fromJson(json, object : TypeToken<List<MediaItem>>() {}.type)
        } catch (e: Exception) { emptyList() }
    }

    // ── Actions ──────────────────────────────────────────────────────────────

    private fun showMediaOptions(item: MediaItem, position: Int) {
        val pinLabel = if (item.isPinned) "Lepas Pin" else "📌 Pin"
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(arrayOf(pinLabel, "🗑️ Hapus", "Batal")) { _, which ->
                when (which) {
                    0 -> togglePin(item, position)
                    1 -> confirmDelete(item)
                }
            }.show()
    }

    private fun togglePin(item: MediaItem, position: Int) {
        val nowPinned = PinManager.togglePin(this, item.path)
        item.isPinned = nowPinned
        if (nowPinned) {
            pinnedItems.add(0, item)
            pinnedAdapter.notifyItemInserted(0)
            Toast.makeText(this, "📌 Disematkan", Toast.LENGTH_SHORT).show()
        } else {
            val idx = pinnedItems.indexOfFirst { it.path == item.path }
            if (idx >= 0) { pinnedItems.removeAt(idx); pinnedAdapter.notifyItemRemoved(idx) }
            Toast.makeText(this, "Pin dilepas", Toast.LENGTH_SHORT).show()
        }
        val allIdx = allMediaItems.indexOfFirst { it.path == item.path }
        if (allIdx >= 0) { allMediaItems[allIdx] = item; allMediaAdapter.notifyItemChanged(allIdx) }
        updatePinnedVisibility()
    }

    private fun confirmDelete(item: MediaItem) {
        AlertDialog.Builder(this)
            .setTitle("Hapus")
            .setMessage("Hapus \"${item.name}\"?")
            .setPositiveButton("Hapus") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    val success = RootHelper.deleteFile(item.path)
                    RootHelper.mediaScan(item.path)
                    withContext(Dispatchers.Main) {
                        if (success) {
                            val allIdx = allMediaItems.indexOfFirst { it.path == item.path }
                            if (allIdx >= 0) { allMediaItems.removeAt(allIdx); allMediaAdapter.notifyItemRemoved(allIdx) }
                            val pinIdx = pinnedItems.indexOfFirst { it.path == item.path }
                            if (pinIdx >= 0) { pinnedItems.removeAt(pinIdx); pinnedAdapter.notifyItemRemoved(pinIdx) }
                            PinManager.unpin(this@MainActivity, item.path)
                            updatePinnedVisibility()
                            Toast.makeText(this@MainActivity, "🗑️ Dihapus", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this@MainActivity, "Gagal menghapus", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun openMedia(item: MediaItem) {
        startActivity(Intent(this, MediaViewerActivity::class.java).apply {
            putExtra("media_path", item.path)
            putExtra("media_type", item.type.name)
        })
    }

    private fun updatePinnedVisibility() {
        val has = pinnedItems.isNotEmpty()
        tvPinnedSection.visibility = if (has) View.VISIBLE else View.GONE
        rvPinned.visibility        = if (has) View.VISIBLE else View.GONE
        tvNoPinned.visibility      = if (!has) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        val pinnedPaths = PinManager.getPinnedPaths(this)
        allMediaItems.forEach { it.isPinned = pinnedPaths.contains(it.path) }
        allMediaAdapter.notifyDataSetChanged()
        pinnedItems.clear()
        pinnedItems.addAll(allMediaItems.filter { it.isPinned })
        pinnedAdapter.notifyDataSetChanged()
        updatePinnedVisibility()
    }
}
