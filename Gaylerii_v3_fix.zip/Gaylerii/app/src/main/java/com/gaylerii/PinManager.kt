package com.gaylerii

import android.content.Context
import android.content.SharedPreferences

object PinManager {

    private const val PREF_NAME = "gaylerii_pins"
    private const val KEY_PINNED = "pinned_paths"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun getPinnedPaths(context: Context): Set<String> {
        return getPrefs(context).getStringSet(KEY_PINNED, emptySet()) ?: emptySet()
    }

    fun pin(context: Context, path: String) {
        val current = getPinnedPaths(context).toMutableSet()
        current.add(path)
        getPrefs(context).edit().putStringSet(KEY_PINNED, current).apply()
    }

    fun unpin(context: Context, path: String) {
        val current = getPinnedPaths(context).toMutableSet()
        current.remove(path)
        getPrefs(context).edit().putStringSet(KEY_PINNED, current).apply()
    }

    fun isPinned(context: Context, path: String): Boolean {
        return getPinnedPaths(context).contains(path)
    }

    fun togglePin(context: Context, path: String): Boolean {
        return if (isPinned(context, path)) {
            unpin(context, path)
            false
        } else {
            pin(context, path)
            true
        }
    }
}
