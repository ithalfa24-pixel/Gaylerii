package com.gaylerii

import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.VideoView
import android.widget.MediaController
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.bumptech.glide.Glide
import java.io.File

class MediaViewerActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var imageView: ImageView
    private lateinit var videoView: VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_media_viewer)

        toolbar = findViewById(R.id.toolbar)
        imageView = findViewById(R.id.imageView)
        videoView = findViewById(R.id.videoView)

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val path = intent.getStringExtra("media_path") ?: return
        val typeStr = intent.getStringExtra("media_type") ?: "IMAGE"
        val type = MediaType.valueOf(typeStr)

        supportActionBar?.title = path.substringAfterLast("/")

        if (type == MediaType.VIDEO) {
            imageView.visibility = View.GONE
            videoView.visibility = View.VISIBLE

            val mediaController = MediaController(this)
            mediaController.setAnchorView(videoView)
            videoView.setMediaController(mediaController)
            videoView.setVideoURI(Uri.fromFile(File(path)))
            videoView.start()
        } else {
            imageView.visibility = View.VISIBLE
            videoView.visibility = View.GONE
            Glide.with(this).load(File(path)).into(imageView)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onPause() {
        super.onPause()
        if (::videoView.isInitialized) videoView.pause()
    }
}
