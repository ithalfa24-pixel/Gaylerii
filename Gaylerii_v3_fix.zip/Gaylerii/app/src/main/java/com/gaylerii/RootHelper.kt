package com.gaylerii

import com.topjohnwu.superuser.Shell
import java.io.File

object RootHelper {

    fun scanAllMedia(): List<MediaItem> {
        val cmd = """find /storage/emulated/0/ -type f \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.webp" -o -iname "*.mp4" -o -iname "*.mkv" -o -iname "*.mov" -o -iname "*.avi" -o -iname "*.3gp" \) 2>/dev/null"""
        val result = Shell.cmd(cmd).exec()
        return result.out.filter { it.isNotBlank() }.mapNotNull { filePath ->
            val name = filePath.substringAfterLast("/")
            val ext = name.substringAfterLast(".").lowercase()
            val type = if (ext in listOf("mp4", "mov", "avi", "mkv", "webm", "3gp"))
                MediaType.VIDEO else MediaType.IMAGE
            MediaItem(path = filePath, name = name, type = type)
        }.sortedByDescending { getFileDate(it.path) }
    }

    fun listMediaFiles(directory: String): List<String> {
        val cmd = """find "$directory" -maxdepth 1 -type f \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.webp" -o -iname "*.gif" -o -iname "*.mp4" -o -iname "*.mkv" -o -iname "*.mov" -o -iname "*.avi" -o -iname "*.3gp" \) 2>/dev/null"""
        val result = Shell.cmd(cmd).exec()
        return result.out.filter { it.isNotBlank() }
    }

    fun getFileSize(path: String): Long {
        return try { File(path).length() } catch (e: Exception) { 0L }
    }

    fun getFileDate(path: String): Long {
        return try { File(path).lastModified() } catch (e: Exception) { 0L }
    }

    fun deleteFile(path: String): Boolean {
        Shell.cmd("rm -f \"$path\"").exec()
        return !File(path).exists()
    }

    fun mediaScan(path: String) {
        Shell.cmd("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d \"file://$path\"").exec()
    }
}
